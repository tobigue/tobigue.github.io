This is the code used in the following paper:

GU-MLT-LT: Sentiment analysis of short messages using linguistic features
and stochastic gradient descent,Tobias Günther and Lenz Furrer, In Second
Joint Conference on Lexical and Computational Semantics (*SEM), Volume 2:
Proceedings of the Seventh International Workshop on Semantic Evaluation
(SemEval 2013), pages 328-332, Atlanta, Georgia, USA, June 2013

PDF: http://aclweb.org/anthology/S/S13/S13-2054.pdf
BibTex: http://aclweb.org/anthology/S/S13/S13-2054.bib

If you want to run this code, you will need to download the SemEval-2013
shared task dataset (see `data/README.md`) and external resources (see
`resources/README.md`), which are not part of this repository.

Furthermore, you will need a working Python 2.7 plus the dependencies given
in `./requirements.txt`

Commands to train the final model and run the shared task evaluation script:

    ./run.sh a sms
    ./run.sh a twitter
    ./run.sh b sms
    ./run.sh b twitter

A 10-fold cross validation experiment can be run like this:

    python ./experiment.py [a|b]
