import sys
import codecs
import locale
from collections import Counter

import numpy as np
import nltk

from datetime import datetime

from sklearn.feature_extraction import DictVectorizer

from sklearn.linear_model import SGDClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.linear_model import Perceptron
from sklearn.svm import LinearSVC
from sklearn.naive_bayes import BernoulliNB, MultinomialNB
from sklearn.neighbors import KNeighborsClassifier, NearestCentroid
from sklearn.dummy import DummyClassifier

from sklearn.grid_search import GridSearchCV
from sklearn import cross_validation
from sklearn import metrics

from readtweets import TweetReader
import extract
from utils import target_mapping


sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)


def avg_f1(gold, pred):
    return metrics.f1_score(gold, pred, average="macro")


def run_quick_experiment(data, target, folds=10):
    vec = DictVectorizer()
    data = vec.fit_transform(data)
    target = np.array(target)

    #data = TfidfTransformer().fit_transform(data)
    #data = SelectPercentile(chi2, percentile=10).fit_transform(data, target)

    print data.shape

    classifiers_to_test = [
        DummyClassifier(strategy='stratified'),
        DummyClassifier(strategy='most_frequent'),
        DummyClassifier(strategy='uniform'),
        MultinomialNB(fit_prior=False),
        BernoulliNB(fit_prior=False),
        LogisticRegression(penalty='l1'),
        LogisticRegression(penalty='l2'),
        SGDClassifier(penalty='l1'),
        SGDClassifier(penalty='l2'),
        SGDClassifier(penalty='elasticnet', alpha=0.001, l1_ratio=0.85, n_iter=100, class_weight="auto"),
        SGDClassifier(penalty='elasticnet', alpha=0.0001, l1_ratio=0.85, n_iter=100),
        Perceptron(),
        LinearSVC(),
        NearestCentroid(metric='l2'),
    ]

    for clf in classifiers_to_test:
        print
        print clf
        scores = cross_validation.cross_val_score(clf, data, target, cv=folds,
                                                  score_func=avg_f1, n_jobs=-1)
        print "Avg. F1: %0.4f (+/- %0.4f)" % (scores.mean(), scores.std() / 2)


def run_cross_validation(data, target, folds=10):
    vec = DictVectorizer()
    data = vec.fit_transform(data).tocsr()
    target = np.array(target)

    all_pred = []
    all_gold = []

    skf = cross_validation.StratifiedKFold(target, folds)
    for train, test in skf:
        X_train, y_train = data[train], target[train]
        X_test, y_test = data[test], target[test]

        #clf = Perceptron(n_iter=100)
        #clf = SGDClassifier(penalty='elasticnet', alpha=0.0001, l1_ratio=0.85,
        #                    n_iter=100)
        clf = SGDClassifier(penalty='elasticnet', alpha=0.001, l1_ratio=0.85,
                            n_iter=100, class_weight='auto')

        clf.fit(X_train, y_train)
        y_pred = clf.predict(X_test)

        all_pred.extend(list(y_pred))
        all_gold.extend(list(y_test))

    print
    print 80 * "="
    print "Detailed results of %s-fold Cross Validation for:" % folds
    print clf
    print 80 * "="
    print
    print "Most informative features (for last fold):"
    show_most_informative_features(vec, clf, n=30)
    print
    print "Classification Report:"
    print
    print metrics.classification_report(all_gold, all_pred)
    print "Average F-measure over classes: %.4f" % avg_f1(all_gold, all_pred)
    print
    print "Confusion Matrix:"
    print nltk.ConfusionMatrix(list(all_gold), list(all_pred))


def run_grid_search(data, target):
    vec = DictVectorizer()
    data = vec.fit_transform(data).tocsr()
    target = np.array(target)

    clf = SGDClassifier(penalty='elasticnet')
    parameters = {
        #'loss': ['hinge', 'log', 'modified_huber'],
        'alpha': [0.0001, 0.005, 0.001, 0.05, 0.01],
        'l1_ratio': [0, 0.15, 0.33, 0.5, 0.66, 0.85, 1],
        'n_iter': [30],
        'class_weight': [None, "auto"]
    }

    grid = GridSearchCV(clf, parameters, n_jobs=-1,
                        cv=10, score_func=avg_f1)
    grid.fit(data, target)

    now = datetime.strftime(datetime.now(), "%Y%m%d-%H%M%S")
    with open('logs/grid_scores_' + now, 'w') as f:
        scores = sorted(grid.grid_scores_, key=lambda x: x[1])
        f.write('\n'.join([str(s).replace('\n', ' ') for s in scores]))

    print "Best score:", grid.best_score_
    print "Best params:", grid.best_params_
    print "Best estimator:", grid.best_estimator_


def show_most_informative_features(vectorizer, clf, n=20):
    if not hasattr(clf, 'coef_'):
        raise NotImplementedError("Only implemented for linear models.")
    try:
        coef = np.asarray(clf.coef_.todense())
    except AttributeError:
        coef = clf.coef_

    if hasattr(clf, 'classes_'):
        classes = clf.classes_
    elif hasattr(clf, 'label_'):
        classes = clf.label_
    else:
        raise AttributeError("No classes found.")

    for i, class_coef in enumerate(coef):
        print
        if len(classes) > 2:
            print "Class %s:" % classes[i]
        coef_w_name = sorted(zip(class_coef, vectorizer.get_feature_names()))
        top = zip(coef_w_name[:n], coef_w_name[:-(n + 1):-1])
        for (c1, f1), (c2, f2) in top:
            print "\t%.4f\t%-15s\t\t%.4f\t%-15s" % (c1, f1, c2, f2)


#################################################

def run_task_a():
    tweets = []

    print "Loading training dataset...",
    tr = TweetReader('data/tweeti-a.dist.full.tsv', task='A')
    tweets.extend(list(tr))
    tr = TweetReader('data/tweeti-a.dev.dist.full.tsv', task='A')
    tweets.extend(list(tr))
    print "done"

    print "Extracting features...",
    fe = extract.SimpleFeatureExtractor()

    data = []
    target = []

    for tweet in tweets:
        senti, swp, ewp = (tweet["sentiment"], tweet["start_pos"],
                           tweet["end_pos"])

        if senti == "objective":
            continue

        token = tweet["text"].split()
        if ewp > len(token):
            # print "WARNING: IndexError for tweet %s" % tweet["sid"]
            continue
        tweet["text"] = ' '.join(token[swp:ewp + 1])

        feature_dict = fe.get_feature_dict(tweet)
        data.append(feature_dict)
        target.append(target_mapping[senti])
    print "done"

    print "Size of dataset: %s samples" % len(target)
    print "Observed classes: %s" % Counter(target)

    #run_quick_experiment(data, target)

    run_cross_validation(data, target, folds=10)

    #run_grid_search(data, target)


def run_task_b():
    tweets = []

    print "Loading training dataset...",
    tr = TweetReader('data/tweeti-b.dist.full.tsv', task='B')
    tweets.extend(list(tr))
    tr = TweetReader('data/tweeti-b.dev.dist.full.tsv', task='B')
    tweets.extend(list(tr))
    print "done"

    print "Extracting features...",
    fe = extract.SimpleFeatureExtractor()

    data = []
    target = []

    for tweet in tweets:
        senti = tweet["sentiment"]
        feature_dict = fe.get_feature_dict(tweet)
        data.append(feature_dict)
        target.append(target_mapping[senti])
    print "done"

    print "Size of dataset: %s samples" % len(target)
    print "Observed classes: %s" % Counter(target)

    #run_quick_experiment(data, target)

    run_cross_validation(data, target, folds=10)

    #run_grid_search(data, target)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print "USAGE: %s [a|b]" % (sys.argv[0])
    elif sys.argv[1] == 'a':
        run_task_a()
    elif sys.argv[1] == 'b':
        run_task_b()
