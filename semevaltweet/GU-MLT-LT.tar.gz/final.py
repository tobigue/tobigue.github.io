import sys
import codecs
import locale
from collections import Counter

import numpy as np

from sklearn.feature_extraction import DictVectorizer
from sklearn.linear_model import SGDClassifier

from readtweets import TweetReader
import extract
from utils import target_mapping, final_mapping


sys.stdout = codecs.getwriter(locale.getpreferredencoding())(sys.stdout)


def task_a_final(testset_filename, output_filename):
    tweets = []

    print "Loading training dataset...",
    tr = TweetReader('data/tweeti-a.dist.full.tsv', task='A')
    tweets.extend(list(tr))
    tr = TweetReader('data/tweeti-a.dev.dist.full.tsv', task='A')
    tweets.extend(list(tr))
    print "done"

    print "Extracting features...",
    fe = extract.SimpleFeatureExtractor()

    data = []
    target = []

    for tweet in tweets:
        senti, swp, ewp = (tweet["sentiment"], tweet["start_pos"],
                           tweet["end_pos"])

        if senti == "objective":
            continue

        token = tweet["text"].split()
        if ewp > len(token):
            # print "WARNING: IndexError for tweet %s" % tweet["sid"]
            continue
        tweet["text"] = ' '.join(token[swp:ewp + 1])

        feature_dict = fe.get_feature_dict(tweet)
        data.append(feature_dict)
        target.append(target_mapping[senti])
    print "done"

    print "Size of dataset: %s samples" % len(target)
    print "Observed classes: %s" % Counter(target)

    # TEST DATA
    test_tweets = []

    print "Loading training dataset...",
    tr_test = TweetReader(testset_filename, task='A')
    test_tweets.extend(list(tr_test))

    data_test = []
    for tweet in test_tweets:
        tweet["text_orig"] = tweet["text"]

        swp, ewp = (tweet["start_pos"], tweet["end_pos"])
        token = tweet["text"].split()
        if ewp > len(token):
            print "WARNING: IndexError for tweet %s" % tweet["sid"]
        tweet["text"] = ' '.join(token[swp:ewp + 1])

        feature_dict = fe.get_feature_dict(tweet)
        data_test.append(feature_dict)
    print "done"

    print "Size of test dataset: %s samples" % len(data_test)

    # TRAINING
    print "Training classifier and predicting...",
    vec = DictVectorizer()
    X = vec.fit_transform(data)
    y = np.array(target)

    clf = SGDClassifier(penalty='elasticnet', alpha=0.0001, l1_ratio=0.85,
                        n_iter=1000, n_jobs=-1)
    clf.fit(X, y)

    X_test = vec.transform(data_test)
    pred = clf.predict(X_test)
    print "done"

    # OUTPUT
    print "Saving to file...",
    with codecs.open(output_filename, 'w', 'utf8') as f:
        for tweet, label in zip(test_tweets, pred):
            line = '\t'.join([tweet["sid"], tweet["uid"],
                              str(tweet["start_pos"]), str(tweet["end_pos"]),
                              final_mapping[label], tweet["text_orig"]]) + '\n'
            f.write(line)
    print "done"


def task_b_final(testset_filename, output_filename):
    tweets = []

    print "Loading training dataset...",
    tr = TweetReader('data/tweeti-b.dist.full.tsv', task='B')
    tweets.extend(list(tr))
    tr = TweetReader('data/tweeti-b.dev.dist.full.tsv', task='B')
    tweets.extend(list(tr))
    print "done"

    #cutoff = int(raw_input("Cutoff: "))
    #tweets = tweets[:cutoff]

    print "Extracting features...",
    fe = extract.SimpleFeatureExtractor()

    data = []
    target = []

    for tweet in tweets:
        senti = tweet["sentiment"]
        feature_dict = fe.get_feature_dict(tweet)
        data.append(feature_dict)
        target.append(target_mapping[senti])
    print "done"

    print "Size of dataset: %s samples" % len(target)
    print "Observed classes: %s" % Counter(target)

    # TEST DATA
    test_tweets = []

    print "Loading test dataset...",
    tr_test = TweetReader(testset_filename, task='B')
    test_tweets.extend(list(tr_test))

    data_test = []
    for tweet in test_tweets:
        feature_dict = fe.get_feature_dict(tweet)
        data_test.append(feature_dict)
    print "done"

    print "Size of test dataset: %s samples" % len(data_test)

    # TRAINING
    print "Training classifier and predicting...",
    vec = DictVectorizer()
    X = vec.fit_transform(data)
    y = np.array(target)

    #clf = Perceptron(n_iter=1000, n_jobs=-1)
    clf = SGDClassifier(penalty='elasticnet', alpha=0.001, l1_ratio=0.85,
                        n_iter=1000, class_weight='auto', n_jobs=-1)
    clf.fit(X, y)

    X_test = vec.transform(data_test)
    pred = clf.predict(X_test)
    print "done"

    # OUTPUT
    print "Saving to file...",
    with codecs.open(output_filename, 'w', 'utf8') as f:
        for tweet, label in zip(test_tweets, pred):
            line = '\t'.join([tweet["sid"], tweet["uid"], final_mapping[label],
                              tweet["text"]]) + '\n'
            f.write(line)
    print "done"


if __name__ == "__main__":
    if len(sys.argv) != 4:
        print "USAGE: %s [a|b] [testset.tsv] [output.tsv]" % (sys.argv[0])
    elif sys.argv[1] == 'a':
        task_a_final(sys.argv[2], sys.argv[3])
    elif sys.argv[1] == 'b':
        task_b_final(sys.argv[2], sys.argv[3])
