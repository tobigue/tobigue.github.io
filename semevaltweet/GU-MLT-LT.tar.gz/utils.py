
target_mapping = {"positive": 1,
                  "neutral": 0,
                  "objective": 0,
                  "objective-OR-neutral": 0,
                  "negative": -1}


final_mapping = {-1: "negative",
                 0: "neutral",
                 1: "positive"}


color = {
    "positive": '\033[92m',
    "neutral": '\033[94m',
    "objective": '\033[94m',
    "objective-OR-neutral": '\033[94m',
    "negative": '\033[91m'
}
