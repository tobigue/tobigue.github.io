#! /bin/bash

if [ "$1" == "a" ] && [ "$2" == "sms" ] ; then
    python final.py a data/sms-test-input-A.tsv data/pred_SMSA.tsv && python data/scorer.py a data/pred_SMSA.tsv data/sms-test-GOLD-A.tsv
fi

if [ "$1" == "a" ] && [ "$2" == "twitter" ] ; then
    python final.py a data/twitter-test-input-A.tsv data/pred_TWA.tsv && python data/scorer.py a data/pred_TWA.tsv data/twitter-test-GOLD-A.tsv
fi

if [ "$1" == "b" ] && [ "$2" == "sms" ] ; then
    python final.py b data/sms-test-input-B.tsv data/pred_SMSB.tsv && python data/scorer.py b data/pred_SMSB.tsv data/sms-test-GOLD-B.tsv
fi

if [ "$1" == "b" ] && [ "$2" == "twitter" ] ; then
    python final.py b data/twitter-test-input-B.tsv data/pred_TWB.tsv && python data/scorer.py b data/pred_TWB.tsv data/twitter-test-GOLD-B.tsv
fi
