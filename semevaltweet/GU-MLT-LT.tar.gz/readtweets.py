import codecs


class TweetReader(object):
    def __init__(self, filename, task):
        self.filename = filename

        if task not in ["A", "B"]:
            raise ValueError("Task must be 'A' or 'B'.")
        self.task = task

    def __iter__(self):
        with codecs.open(self.filename, 'r', 'utf8') as f:
            for i, line in enumerate(f):
                line = line.strip('\r\n')
                fields = line.split('\t')

                if self.task == "A" and len(fields) == 6:
                    sid, uid, swp, ewp, senti, text = fields
                    if text != "Not Available":
                        yield {
                            "sid": sid,
                            "uid": uid,
                            "start_pos": int(swp),
                            "end_pos": int(ewp),
                            "sentiment": senti,
                            "text": text
                        }
                elif self.task == "B" and len(fields) == 4:
                    sid, uid, senti, text = fields
                    if text != "Not Available":
                        yield {
                            "sid": sid,
                            "uid": uid,
                            "sentiment": senti.strip('"'),
                            "text": text
                        }
                else:
                    error = "Malformed line: %s (too many/few tabs)" % (i + 1)
                    raise ValueError(error)
