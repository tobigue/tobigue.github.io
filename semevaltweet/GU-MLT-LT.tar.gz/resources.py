

class WordCluster(object):
    def __init__(self):
        cluster_mapping = {}
        with open("resources/50mpaths2.txt") as f:
            for line in f:
                if not line.strip():
                    continue
                cluster, word, count = line.strip().split('\t')
                cluster_mapping[word] = cluster
        self.cluster_mapping = cluster_mapping

    def get_cluster(self, word):
        return self.cluster_mapping.get(word, None)


class SentiWordNet(object):
    def __init__(self):
        pos_score = {}
        neg_score = {}

        with open("resources/SentiWordNet_3.0.0_20130122.txt") as f:
            for line in f:
                line = line.strip()

                if not line or line.startswith('#'):
                    continue

                postag, wid, pos, neg, synset, exmpl = line.split('\t')

                for token in synset.split():
                    word = token.split('#')[0]

                    pos_score[word] = float(pos)
                    neg_score[word] = float(neg)

        self.pos_score = pos_score
        self.neg_score = neg_score

    def get_score(self, word):
        return self.pos_score.get(word, 0), self.neg_score.get(word, 0)


class WordList(object):
    def __init__(self):
        wl = set()

        with open("resources/wordsEn.txt") as f:
            for line in f:
                line = line.strip()

                if not line:
                    continue

                wl.add(line)

        self.wl = wl

    def __contains__(self, word):
        return word in self.wl
