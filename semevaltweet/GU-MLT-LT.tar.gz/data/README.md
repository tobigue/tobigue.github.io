This folder holds the training, development and test datasets.
Sadly we can not publish the datasets.

For information about obtaining the SemEval-2013: Sentiment Analysis in Twitter
(Task 2) dataset please see http://www.cs.york.ac.uk/semeval-2013/task2/.

Missing files in this folder:

    sms-test-GOLD-B.tsv
    sms-test-input-B.tsv
    tweeti-a.dist.full.tsv
    tweeti-b.dist.full.tsv
    twitter-test-GOLD-B.tsv
    twitter-test-input-B.tsv
    sms-test-GOLD-A.tsv
    sms-test-input-A.tsv
    tweeti-a.dev.dist.full.tsv
    tweeti-b.dev.dist.full.tsv
    twitter-test-GOLD-A.tsv
    twitter-test-input-A.tsv
