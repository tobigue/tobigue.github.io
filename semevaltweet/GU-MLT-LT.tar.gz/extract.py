import re
import itertools

from nltk.stem import PorterStemmer

import preprocessing as pp
from resources import WordCluster, SentiWordNet, WordList


class SimpleFeatureExtractor(object):

    ps = PorterStemmer()
    wc = WordCluster()
    swn = SentiWordNet()
    wl = WordList()

    def get_feature_dict(self, tweet):
        features = {}

        neg = False

        tokens = pp.tokenize(tweet["text"])
        for i, token in enumerate(tokens):
            token_normalized = pp.normalize(token)
            token_collapsed = token_normalized if token_normalized in self.wl \
                else pp.collapse(token_normalized)

            stem = self.ps.stem(token_collapsed)

            pos_score, neg_score = self.swn.get_score(token_collapsed)

            features["SWN_POS"] = features.get("SWN_POS", 0) + pos_score
            features["SWN_NEG"] = features.get("SWN_NEG", 0) + neg_score

            cluster_tok = self.wc.get_cluster(token)
            cluster_nor = self.wc.get_cluster(token_normalized)
            cluster_col = self.wc.get_cluster(token_collapsed)

            if neg:
                token = "NEG=" + token
                token_collapsed = "NEG=" + token_collapsed
                stem = "NEG=" + stem

            #features[token] = True
            features[token_normalized] = True
            #features[token_collapsed] = True

            features[stem] = True

            cluster_prefix = "CLSTR="  # if not neg else "NCLSTR="

            if cluster_tok:
                features[cluster_prefix + cluster_tok] = True

            if cluster_nor:
                features[cluster_prefix + cluster_nor] = True

            if cluster_col:
                features[cluster_prefix + cluster_col] = True

            if cluster_col in ["00111100",
                               "001111010",
                               "0011110110",
                               "0011110111",
                               "00111110"] \
            or token_collapsed in ["not", "no"] \
            or token_collapsed.endswith("n't"):
                neg = True

            if re.search(r"^[.!?,;:]+$", token_collapsed):
                neg = False

        return features
