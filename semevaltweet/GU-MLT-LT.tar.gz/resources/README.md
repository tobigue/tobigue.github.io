This folder holds external resources.
Sadly we can not publish those resources.

Missing files in this folder:

    50mpath2.txt
    SentiWordNet_3.0.0_20130122.txt
    wordsEn.txt

URLs for obtaining these resources:

    http://www.ark.cs.cmu.edu/TweetNLP/
    http://sentiwordnet.isti.cnr.it/
    http://www-01.sil.org/linguistics/wordlists/english/
