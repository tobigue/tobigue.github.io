import itertools
import regex


tokenizer = regex.compile(r"https?://[\S]+|[[^\W_]||[']]+|[[\W_]--[\s]]+",
                          flags=regex.V1)


def tokenize(text):
    return tokenizer.findall(text)


def collapse(token):
    return ''.join([elem for elem, _ in itertools.groupby(token)])


def normalize(token):
    token = token.lower()
    token = regex.sub(r'\d', '0', token)
    return token
